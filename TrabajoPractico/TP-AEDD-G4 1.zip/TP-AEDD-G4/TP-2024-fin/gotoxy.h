 void gotoxy(int x,int y);
