#include <string>
using namespace std;

string binarioR(int n);
string binarioI(int n);
int ConjeturaR(int n, int& ma);
int ConjeturaI(int n, int& ma);
void Texto_Decimal_Binario();
void Texto_Conjetura();
