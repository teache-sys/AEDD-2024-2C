#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

void encriptar(char a[]);
void desencriptar(char a[]);
