#include <windows.h>

void logo();
void logoif(int);
void animacion_bienvenida();
void Menu_Principal_logo();
void Menu_Algoritmos_Logo();
void Pantalla_Bienvenida();
void menuPrincipal_registro_animacion();
void menuPrincipal_InSesion_animacion();
void menuPrincipal_Algoritmos_animacion();
void menuPrincipal_MarioBros_animacion();
void logoJuegos();
