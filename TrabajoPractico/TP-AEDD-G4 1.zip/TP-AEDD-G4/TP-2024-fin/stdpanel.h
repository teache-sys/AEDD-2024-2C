#define MAXIMO 20

using namespace std;

void cargarTablero(char [][MAXIMO], int, int); // carga el tablero recibido por par�metro con piedras y aves
