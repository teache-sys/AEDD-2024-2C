#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

void Menu_Principal();
void Menu_Principal2();
void Menu_Registro(bool& ok);
void Menu_InSesion(bool& ok);
void Menu_Algoritmos();
void Menu_MarioBros();
void Menu_Algoritmo1_Recursivo();
void Menu_Algoritmo1_Iterativo();
void Menu_Algoritmo2_Recursivo();
void Menu_Algoritmo2_Iterativo();
void mostrarControles();

